import math

import scipy

from scipy import special

import random  #used to shuffel training data 

import numpy as np  #used to do matrix operations

class Network(object): #what does this mean? (object)????.

    def __init__(self, sizes):

        self.num_layers = len(sizes)  #sizes = ["layer 1 no. of neurons", "layer 2 no. of neurons", ..... , "layer n no. of neurons"]

        self.sizes = sizes

        self.biases = [np.random.randn(y, 1) for y in sizes[1:]]

        self.weights = [np.random.randn(y, x) for x, y in zip(sizes[:-1], sizes[1:])]
    
    def sigmoid(self, z):

        return scipy.special.expit(z)

    def feedforward(self, a):

        for b, w in zip(self.biases, self.weights):

            a = self.sigmoid(np.dot(w, a)+b) #here in numpy dot products and vector mutplication mean the same "w = y*1 & a = x*1 and np.dot(w, a) = y*1"

        return a

    def SGD(self, training_data, epochs, mini_batch_size, eta, test_data=None):  # eta = learning_rate

        if test_data:

            n_test = len(test_data)

        for j in range(epochs):

            random.shuffle(training_data)

            mini_batches = [training_data[k:mini_batch_size+k] for k in range(0, len(training_data), mini_batch_size)]

            for mini_batch in mini_batches:

                self.update_mini_batch(mini_batch, eta)

            if test_data:

                print(f" epoch no. {j}, progress {self.evaluate(test_data)}, {n_test}")  # returns "correct_result / total_no_of_given_data"

            else:

                print(f"epoch no. {j} completed")

    def backprop(self, x, y):  # return layer by layer nebula_b, nebula_w
        
        nabla_b = [np.zeros(b.shape) for b in self.biases]

        nabla_w = [np.zeros(w.shape) for w in self.weights]

        activation = x

        activations = [x] # output of sigmoid_function

        zs = [] # wx+b

        for b, w in zip(self.biases, self.weights):
        
            z = np.dot(w, activation)+b
        
            zs.append(z)
        
            activation = sigmoid(z)
        
            activations.append(activation)
        
        #print(self.cost_derivative(activations[-1], y))

        #print(sigmoid_prime(zs[-1]))
        
        delta = np.dot(self.cost_derivative(activations[-1], y) , sigmoid_prime(zs[-1])) # should go from back from output layer --> input layer
        
        #print(np.shape(delta))

        nabla_b[-1] = delta # delta should be a 10*1 matrix 
        
        nabla_w[-1] = np.dot(delta, activations[-2].transpose())  # transpose because we need column vector representing the activations and not a single number from the output

        for l in range(2, self.num_layers):

            z = zs[-l]

            sp = sigmoid_prime(z)

            delta = np.dot(self.weights[-l+1].transpose(), delta) * sp

            nabla_b[-l] = delta

            nabla_w[-l] = np.dot(delta, activations[-l-1].transpose())

        return (nabla_b, nabla_w)

    def update_mini_batch(self, mini_batch, eta):
        """Update the network's weights and biases by applying
        gradient descent using backpropagation to a single mini batch.
        The "mini_batch" is a list of tuples "(x, y)", and "eta"
        is the learning rate."""
        nabla_b = [np.zeros(b.shape) for b in self.biases]
        nabla_w = [np.zeros(w.shape) for w in self.weights]
        for x, y in mini_batch:
            delta_nabla_b, delta_nabla_w = self.backprop(x, y)
            nabla_b = [nb+dnb for nb, dnb in zip(nabla_b, delta_nabla_b)]
            nabla_w = [nw+dnw for nw, dnw in zip(nabla_w, delta_nabla_w)]
        self.weights = [w-(eta/len(mini_batch))*nw for w, nw in zip(self.weights, nabla_w)]
        self.biases = [b-(eta/len(mini_batch))*nb for b, nb in zip(self.biases, nabla_b)]
    def cost_derivative(self, output_activations, y):

        return output_activations - y
    
    def evaluate(self, test_data):

        # we are using x, y insted of (x, y)

        test_results = [(np.argmax(self.feedforward(x)), np.argmax(y)) for x, y in test_data]

        print(test_results[-10])

        return sum(int(int(x)==int(y)) for x, y in test_results)

#does 1 make any difference than 1.0

def sigmoid(z):

    return scipy.special.expit(z)

def sigmoid_prime(z):

    return np.ones((len(z), 1))
            

'''

wierd outputs

>>> net.SGD(td, 30, 10, 0.5, test_data =tsd )
C:\Users\DELL\neural_networks_and_deep_learning_from_scratch\digit_recognisation.py:138: RuntimeWarning: overflow encountered in exp
  return 1.0/(1.0+np.exp(-z))
(0, 0)
 epoch no. 0, progress 9980, 10000
(0, 0)
 epoch no. 1, progress 9980, 10000
(1, 0)
 epoch no. 2, progress 0, 10000
(0, 0)
 epoch no. 3, progress 9982, 10000
(0, 0)
 epoch no. 4, progress 9980, 10000
(0, 0)
 epoch no. 5, progress 9982, 10000
(1, 0)
 epoch no. 6, progress 0, 10000
(3, 0)
 epoch no. 7, progress 2, 10000
(0, 0)
 epoch no. 8, progress 9982, 10000
(0, 0)
 epoch no. 9, progress 9982, 10000

 '''

