import gzip

import os

import _pickle as cPickle

import numpy as np

def load_data():

    file = open('mnist.pkl', 'rb')
    
    training_data, validation_data, test_data = cPickle.load(file, encoding="latin1") # formats of td(50000), vd(10000), tsd(10000) = ([[], [], [],...[]], [1, 3, 5, 2,......, 5])

    file.close()

    return (training_data, validation_data, test_data)

def load_data_wrapper():

    td, vd, tsd = load_data()

    td_inputs = [np.reshape(x, (784, 1)) for x in td[0]]

    td_outputs =  [vectorized_result(x) for x in td[1]] # convert td outputs to unit vectors representing the otput index with '1' and others with '0' 

    vd_inputs = [np.reshape(x, (784, 1)) for x in td[0]]

    tsd_inputs = [np.reshape(x, (784, 1)) for x in tsd[0]]

    training_data = list(zip(td_inputs, td_outputs))

    validation_data = list(zip(vd_inputs, vd[1]))

    test_data = list(zip(tsd_inputs, tsd[1]))

    return (training_data, validation_data, test_data)

def vectorized_result(j):

    r = np.zeros(10)

    r[j] = 1

    return r



